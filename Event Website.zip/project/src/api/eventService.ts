import { Event, EventCategory } from '../types';
import { events } from '../data/events';

// Simulate scraping service
export const fetchEvents = (): Promise<Event[]> => {
  return new Promise((resolve) => {
    // Simulate API delay
    setTimeout(() => {
      resolve(events);
    }, 800);
  });
};

export const fetchFeaturedEvents = (): Promise<Event[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(events.filter(event => event.featured));
    }, 500);
  });
};

export const fetchEventsByCategory = (category: EventCategory): Promise<Event[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(events.filter(event => event.category === category));
    }, 500);
  });
};

export const fetchEventById = (id: string): Promise<Event | undefined> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(events.find(event => event.id === id));
    }, 300);
  });
};

export const searchEvents = (query: string): Promise<Event[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const lowercaseQuery = query.toLowerCase();
      resolve(
        events.filter(
          event => 
            event.title.toLowerCase().includes(lowercaseQuery) || 
            event.description.toLowerCase().includes(lowercaseQuery) ||
            event.location.toLowerCase().includes(lowercaseQuery) ||
            event.category.toLowerCase().includes(lowercaseQuery)
        )
      );
    }, 500);
  });
};

export const submitEmailForTickets = (email: string, optIn: boolean, eventId: string): Promise<boolean> => {
  return new Promise((resolve) => {
    // Simulate API call to save email
    console.log(`Email collected: ${email}, Opt-in: ${optIn}, Event: ${eventId}`);
    setTimeout(() => {
      resolve(true);
    }, 600);
  });
};