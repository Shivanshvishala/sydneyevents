export const formatDate = (dateString: string): string => {
  const options: Intl.DateTimeFormatOptions = {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  };
  
  return new Date(dateString).toLocaleDateString('en-AU', options);
};

export const formatPrice = (price: string): string => {
  if (price.toLowerCase().includes('free')) return 'Free';
  return price;
};

export const formatEventTime = (time: string): string => {
  const [hours, minutes] = time.split(':');
  const hour = parseInt(hours, 10);
  const ampm = hour >= 12 ? 'PM' : 'AM';
  const formattedHour = hour % 12 || 12;
  
  return `${formattedHour}:${minutes} ${ampm}`;
};

export const getCategoryColor = (category: string): string => {
  const colors: Record<string, string> = {
    'music': 'bg-purple-600',
    'arts': 'bg-blue-600',
    'sports': 'bg-green-600',
    'food': 'bg-orange-600',
    'nightlife': 'bg-pink-600',
    'family': 'bg-yellow-600',
    'community': 'bg-teal-600',
    'other': 'bg-gray-600'
  };
  
  return colors[category] || colors.other;
};

export const getCategoryTextColor = (category: string): string => {
  const colors: Record<string, string> = {
    'music': 'text-purple-600',
    'arts': 'text-blue-600',
    'sports': 'text-green-600',
    'food': 'text-orange-600',
    'nightlife': 'text-pink-600',
    'family': 'text-yellow-600',
    'community': 'text-teal-600',
    'other': 'text-gray-600'
  };
  
  return colors[category] || colors.other;
};

export const truncateText = (text: string, maxLength: number): string => {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength) + '...';
};