import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { FeaturedEvents } from './components/FeaturedEvents';
import { EventsList } from './components/EventsList';
import { Footer } from './components/Footer';
import { EmailModal } from './components/EmailModal';
import { EventDetailsModal } from './components/EventDetailsModal';
import { Event } from './types';
import { fetchEventById } from './api/eventService';

function App() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedEventId, setSelectedEventId] = useState<string | null>(null);
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [showEventDetailsModal, setShowEventDetailsModal] = useState(false);
  
  const heroBackgroundImages = [
    'https://images.pexels.com/photos/1190297/pexels-photo-1190297.jpeg',
    'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg',
    'https://images.pexels.com/photos/2456439/pexels-photo-2456439.jpeg'
  ];
  
  useEffect(() => {
    if (selectedEventId) {
      const loadEvent = async () => {
        try {
          const event = await fetchEventById(selectedEventId);
          if (event) {
            setSelectedEvent(event);
          }
        } catch (err) {
          console.error('Failed to load event details', err);
        }
      };
      
      loadEvent();
    }
  }, [selectedEventId]);
  
  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };
  
  const handleTicketClick = (eventId: string) => {
    setSelectedEventId(eventId);
    setShowEmailModal(true);
  };
  
  const handleEventClick = (eventId: string) => {
    setSelectedEventId(eventId);
    setShowEventDetailsModal(true);
  };
  
  const handleEmailSubmit = (ticketUrl: string) => {
    setShowEmailModal(false);
    // In a real app, we would redirect to the ticketUrl
    window.open(ticketUrl, '_blank');
  };
  
  const handleCloseEmailModal = () => {
    setShowEmailModal(false);
    setSelectedEventId(null);
  };
  
  const handleCloseEventDetailsModal = () => {
    setShowEventDetailsModal(false);
    setSelectedEventId(null);
  };
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header onSearch={handleSearch} />
      
      <main className="flex-grow">
        <Hero backgroundImages={heroBackgroundImages} />
        
        <FeaturedEvents onTicketClick={handleTicketClick} />
        
        <EventsList 
          searchQuery={searchQuery} 
          onTicketClick={handleTicketClick} 
        />
      </main>
      
      <Footer />
      
      {showEmailModal && selectedEvent && (
        <EmailModal 
          event={selectedEvent} 
          onClose={handleCloseEmailModal} 
          onSubmit={handleEmailSubmit} 
        />
      )}
      
      {showEventDetailsModal && selectedEvent && (
        <EventDetailsModal 
          event={selectedEvent} 
          onClose={handleCloseEventDetailsModal} 
          onTicketClick={handleTicketClick} 
        />
      )}
    </div>
  );
}

export default App;