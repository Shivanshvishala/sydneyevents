export interface Event {
  id: string;
  title: string;
  description: string;
  date: string;
  time: string;
  location: string;
  venue: string;
  image: string;
  category: EventCategory;
  price: string;
  ticketUrl: string;
  featured?: boolean;
}

export type EventCategory = 
  | 'music' 
  | 'arts' 
  | 'sports' 
  | 'food' 
  | 'nightlife' 
  | 'family' 
  | 'community'
  | 'other';

export interface EmailSignup {
  email: string;
  optIn: boolean;
  eventId: string;
}