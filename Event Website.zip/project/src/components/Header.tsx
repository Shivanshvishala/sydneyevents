import React, { useState } from 'react';
import { Search, Menu, X } from 'lucide-react';
import { Link } from './Link';

interface HeaderProps {
  onSearch: (query: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ onSearch }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(searchQuery);
  };

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <header className="sticky top-0 z-50 bg-white shadow-md transition-all duration-300">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-2">
            <div className="text-2xl font-bold text-indigo-600">Sydney<span className="text-pink-500">Events</span></div>
          </Link>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/" className="font-medium text-gray-700 hover:text-indigo-600 transition-colors">Home</Link>
            <Link to="/events" className="font-medium text-gray-700 hover:text-indigo-600 transition-colors">All Events</Link>
            <Link to="/calendar" className="font-medium text-gray-700 hover:text-indigo-600 transition-colors">Calendar</Link>
            <Link to="/categories" className="font-medium text-gray-700 hover:text-indigo-600 transition-colors">Categories</Link>
          </nav>
          
          {/* Search Bar */}
          <div className="hidden md:block">
            <form onSubmit={handleSearchSubmit} className="flex items-center">
              <input
                type="text"
                placeholder="Search events..."
                className="px-4 py-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <button 
                type="submit" 
                className="bg-indigo-600 text-white p-2 rounded-r-md hover:bg-indigo-700 transition-colors"
                aria-label="Search"
              >
                <Search size={20} />
              </button>
            </form>
          </div>
          
          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-gray-700 hover:text-indigo-600 focus:outline-none"
            onClick={toggleMobileMenu}
            aria-label={mobileMenuOpen ? 'Close menu' : 'Open menu'}
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
        
        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden mt-4 py-4 border-t border-gray-200 animate-fadeIn">
            <nav className="flex flex-col space-y-4">
              <Link to="/" className="font-medium text-gray-700 hover:text-indigo-600 transition-colors">Home</Link>
              <Link to="/events" className="font-medium text-gray-700 hover:text-indigo-600 transition-colors">All Events</Link>
              <Link to="/calendar" className="font-medium text-gray-700 hover:text-indigo-600 transition-colors">Calendar</Link>
              <Link to="/categories" className="font-medium text-gray-700 hover:text-indigo-600 transition-colors">Categories</Link>
            
              <form onSubmit={handleSearchSubmit} className="flex items-center mt-4">
                <input
                  type="text"
                  placeholder="Search events..."
                  className="px-4 py-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent w-full"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <button 
                  type="submit" 
                  className="bg-indigo-600 text-white p-2 rounded-r-md hover:bg-indigo-700 transition-colors"
                  aria-label="Search"
                >
                  <Search size={20} />
                </button>
              </form>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};