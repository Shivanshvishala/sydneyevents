import React, { useEffect, useState } from 'react';
import { Event, EventCategory } from '../types';
import { fetchEvents, fetchEventsByCategory, searchEvents } from '../api/eventService';
import { EventCard } from './EventCard';
import { CategoryFilter } from './CategoryFilter';

interface EventsListProps {
  searchQuery?: string;
  onTicketClick: (eventId: string) => void;
}

export const EventsList: React.FC<EventsListProps> = ({ searchQuery = '', onTicketClick }) => {
  const [events, setEvents] = useState<Event[]>([]);
  const [filteredEvents, setFilteredEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);
  const [category, setCategory] = useState<EventCategory | null>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    const loadEvents = async () => {
      try {
        setLoading(true);
        let data: Event[];
        
        if (searchQuery) {
          data = await searchEvents(searchQuery);
        } else if (category) {
          data = await fetchEventsByCategory(category);
        } else {
          data = await fetchEvents();
        }
        
        setEvents(data);
        setFilteredEvents(data);
      } catch (err) {
        setError('Failed to load events');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    loadEvents();
  }, [searchQuery, category]);

  const handleCategorySelect = (selectedCategory: EventCategory | null) => {
    setCategory(selectedCategory);
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="animate-pulse">
          <div className="h-10 bg-gray-200 max-w-md mb-8 rounded"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="bg-gray-200 h-80 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center text-red-500">
          <p>{error}</p>
        </div>
      </div>
    );
  }

  return (
    <section className="container mx-auto px-4 py-8">
      <h2 className="text-2xl font-bold mb-4">
        {searchQuery 
          ? `Search Results for "${searchQuery}"` 
          : category 
            ? `${category.charAt(0).toUpperCase() + category.slice(1)} Events` 
            : 'All Events'}
      </h2>
      
      <CategoryFilter selectedCategory={category} onSelectCategory={handleCategorySelect} />
      
      {filteredEvents.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-xl text-gray-600">No events found. Try a different search or category.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredEvents.map((event) => (
            <EventCard key={event.id} event={event} onTicketClick={onTicketClick} />
          ))}
        </div>
      )}
    </section>
  );
};