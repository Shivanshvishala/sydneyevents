import React from 'react';
import { EventCategory } from '../types';
import { getCategoryColor } from '../utils/formatters';

interface CategoryFilterProps {
  selectedCategory: EventCategory | null;
  onSelectCategory: (category: EventCategory | null) => void;
}

export const CategoryFilter: React.FC<CategoryFilterProps> = ({
  selectedCategory,
  onSelectCategory
}) => {
  const categories: { id: EventCategory; label: string }[] = [
    { id: 'music', label: 'Music' },
    { id: 'arts', label: 'Arts & Culture' },
    { id: 'sports', label: 'Sports' },
    { id: 'food', label: 'Food & Drink' },
    { id: 'nightlife', label: 'Nightlife' },
    { id: 'family', label: 'Family' },
    { id: 'community', label: 'Community' },
    { id: 'other', label: 'Other' }
  ];

  return (
    <div className="flex flex-wrap gap-2 py-4">
      <button
        className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
          selectedCategory === null
            ? 'bg-indigo-600 text-white'
            : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
        }`}
        onClick={() => onSelectCategory(null)}
      >
        All
      </button>
      
      {categories.map((category) => (
        <button
          key={category.id}
          className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
            selectedCategory === category.id
              ? `${getCategoryColor(category.id)} text-white`
              : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
          }`}
          onClick={() => onSelectCategory(category.id)}
        >
          {category.label}
        </button>
      ))}
    </div>
  );
};