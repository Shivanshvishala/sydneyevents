import React from 'react';
import { Link } from './Link';
import { Mail, Instagram, Twitter, Facebook } from 'lucide-react';

export const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <h3 className="text-xl font-bold">Sydney<span className="text-pink-500">Events</span></h3>
            <p className="text-gray-400">Your guide to all events happening in Sydney, Australia. Discover, experience, and enjoy!</p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors" aria-label="Instagram">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors" aria-label="Twitter">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors" aria-label="Facebook">
                <Facebook size={20} />
              </a>
              <a href="mailto:info@sydneyevents.com" className="text-gray-400 hover:text-white transition-colors" aria-label="Email">
                <Mail size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link to="/" className="text-gray-400 hover:text-white transition-colors">Home</Link></li>
              <li><Link to="/events" className="text-gray-400 hover:text-white transition-colors">All Events</Link></li>
              <li><Link to="/calendar" className="text-gray-400 hover:text-white transition-colors">Calendar</Link></li>
              <li><Link to="/categories" className="text-gray-400 hover:text-white transition-colors">Categories</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Categories</h3>
            <ul className="space-y-2">
              <li><Link to="/category/music" className="text-gray-400 hover:text-white transition-colors">Music</Link></li>
              <li><Link to="/category/arts" className="text-gray-400 hover:text-white transition-colors">Arts & Culture</Link></li>
              <li><Link to="/category/food" className="text-gray-400 hover:text-white transition-colors">Food & Drink</Link></li>
              <li><Link to="/category/sports" className="text-gray-400 hover:text-white transition-colors">Sports</Link></li>
              <li><Link to="/category/family" className="text-gray-400 hover:text-white transition-colors">Family</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact</h3>
            <address className="not-italic text-gray-400">
              <p>123 Sydney Avenue</p>
              <p>Sydney, NSW 2000</p>
              <p>Australia</p>
              <p className="mt-2">
                <a href="mailto:info@sydneyevents.com" className="hover:text-white transition-colors">info@sydneyevents.com</a>
              </p>
              <p>
                <a href="tel:+61293456789" className="hover:text-white transition-colors">+61 2 9345 6789</a>
              </p>
            </address>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-500">
          <p>&copy; {currentYear} SydneyEvents. All rights reserved.</p>
          <div className="mt-2 flex justify-center space-x-4">
            <Link to="/privacy" className="hover:text-white transition-colors">Privacy Policy</Link>
            <Link to="/terms" className="hover:text-white transition-colors">Terms of Service</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};