import React, { useState, useEffect } from 'react';
import { Link } from './Link';

interface HeroProps {
  backgroundImages: string[];
}

export const Hero: React.FC<HeroProps> = ({ backgroundImages }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prevIndex) => (prevIndex + 1) % backgroundImages.length);
    }, 5000);
    
    return () => clearInterval(interval);
  }, [backgroundImages.length]);
  
  return (
    <section className="relative h-[60vh] md:h-[70vh] overflow-hidden">
      {/* Background image slider */}
      {backgroundImages.map((image, index) => (
        <div
          key={index}
          className={`absolute inset-0 w-full h-full bg-cover bg-center transition-opacity duration-1000 ease-in-out ${
            index === currentImageIndex ? 'opacity-100' : 'opacity-0'
          }`}
          style={{ backgroundImage: `url(${image})` }}
        >
          {/* Overlay gradient */}
          <div className="absolute inset-0 bg-gradient-to-b from-black/70 to-black/30"></div>
        </div>
      ))}
      
      {/* Content */}
      <div className="container mx-auto px-4 h-full flex flex-col justify-center items-center text-center relative z-10">
        <h1 className="text-4xl md:text-6xl font-bold text-white mb-4 animate-fadeInUp">
          Discover <span className="text-pink-500">Sydney's</span> Best Events
        </h1>
        <p className="text-xl text-white/90 max-w-2xl mb-8 animate-fadeInUp animation-delay-300">
          Your ultimate guide to concerts, festivals, shows, and happenings across Sydney. 
          Never miss another exciting event in Australia's most vibrant city.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 animate-fadeInUp animation-delay-600">
          <Link 
            to="/events" 
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-3 rounded-md font-medium transition-colors"
          >
            Explore Events
          </Link>
          <Link 
            to="/categories" 
            className="bg-transparent hover:bg-white/20 text-white border-2 border-white px-8 py-3 rounded-md font-medium transition-colors"
          >
            Browse Categories
          </Link>
        </div>
      </div>
      
      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <svg 
          className="w-6 h-6 text-white" 
          fill="none" 
          strokeWidth="2" 
          viewBox="0 0 24 24" 
          stroke="currentColor"
        >
          <path d="M19 14l-7 7m0 0l-7-7m7 7V3"></path>
        </svg>
      </div>
    </section>
  );
};