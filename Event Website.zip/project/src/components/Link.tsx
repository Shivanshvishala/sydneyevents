import React from 'react';

interface LinkProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
  to: string;
  children: React.ReactNode;
}

export const Link: React.FC<LinkProps> = ({ to, children, ...props }) => {
  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    // In a real app, we'd use a router here
    console.log(`Navigating to: ${to}`);
    
    // For this demo, we'll just make sure the home page is shown
    if (to === '/') {
      window.scrollTo(0, 0);
    }
    
    if (props.onClick) {
      props.onClick(e);
    }
  };
  
  return (
    <a href={to} onClick={handleClick} {...props}>
      {children}
    </a>
  );
};