import React from 'react';
import { X, Calendar, Clock, MapPin, Tag, DollarSign } from 'lucide-react';
import { Event } from '../types';
import { formatDate, formatEventTime, getCategoryTextColor } from '../utils/formatters';

interface EventDetailsModalProps {
  event: Event;
  onClose: () => void;
  onTicketClick: (eventId: string) => void;
}

export const EventDetailsModal: React.FC<EventDetailsModalProps> = ({ 
  event, 
  onClose,
  onTicketClick
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 animate-fadeIn">
      <div 
        className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto relative animate-scaleIn"
        onClick={(e) => e.stopPropagation()}
      >
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 z-10 bg-white/80 p-1 rounded-full text-gray-700 hover:text-gray-900 transition-colors"
          aria-label="Close"
        >
          <X size={24} />
        </button>
        
        <div className="relative h-72 overflow-hidden">
          <img 
            src={event.image} 
            alt={event.title} 
            className="w-full h-full object-cover"
          />
          <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black/70 to-transparent"></div>
          
          <div className="absolute bottom-4 left-4 text-white">
            <div className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${getCategoryTextColor(event.category)} bg-white mb-2`}>
              {event.category.charAt(0).toUpperCase() + event.category.slice(1)}
            </div>
            <h2 className="text-2xl font-bold">{event.title}</h2>
          </div>
        </div>
        
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div className="flex items-center">
              <Calendar size={20} className="text-indigo-600 mr-3" />
              <div>
                <p className="text-sm text-gray-500">Date</p>
                <p className="font-medium">{formatDate(event.date)}</p>
              </div>
            </div>
            
            <div className="flex items-center">
              <Clock size={20} className="text-indigo-600 mr-3" />
              <div>
                <p className="text-sm text-gray-500">Time</p>
                <p className="font-medium">{formatEventTime(event.time)}</p>
              </div>
            </div>
            
            <div className="flex items-center">
              <DollarSign size={20} className="text-indigo-600 mr-3" />
              <div>
                <p className="text-sm text-gray-500">Price</p>
                <p className="font-medium">{event.price}</p>
              </div>
            </div>
          </div>
          
          <div className="mb-6">
            <h3 className="text-lg font-semibold mb-2">Location</h3>
            <div className="flex items-start">
              <MapPin size={20} className="text-indigo-600 mr-3 mt-1 flex-shrink-0" />
              <div>
                <p className="font-medium">{event.venue}</p>
                <p className="text-gray-600">{event.location}</p>
              </div>
            </div>
          </div>
          
          <div className="mb-8">
            <h3 className="text-lg font-semibold mb-2">About This Event</h3>
            <p className="text-gray-700 leading-relaxed">{event.description}</p>
          </div>
          
          <div className="flex justify-end">
            <button
              onClick={() => onTicketClick(event.id)}
              className="bg-pink-600 hover:bg-pink-700 text-white px-8 py-3 rounded-md font-medium transition-colors"
            >
              GET TICKETS
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};