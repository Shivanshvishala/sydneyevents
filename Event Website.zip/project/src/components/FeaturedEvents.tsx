import React, { useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Event } from '../types';
import { fetchFeaturedEvents } from '../api/eventService';
import { EventCard } from './EventCard';

interface FeaturedEventsProps {
  onTicketClick: (eventId: string) => void;
}

export const FeaturedEvents: React.FC<FeaturedEventsProps> = ({ onTicketClick }) => {
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const loadEvents = async () => {
      try {
        const data = await fetchFeaturedEvents();
        setEvents(data);
      } catch (err) {
        setError('Failed to load featured events');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    loadEvents();
  }, []);

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold text-center mb-12">Featured Events</h2>
        <div className="flex justify-center">
          <div className="animate-pulse space-y-8">
            <div className="h-4 bg-gray-300 rounded w-32 mx-auto"></div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[1, 2, 3].map((i) => (
                <div key={i} className="bg-gray-200 h-80 rounded-lg"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-16">
        <div className="text-center text-red-500">
          <p>{error}</p>
        </div>
      </div>
    );
  }

  if (events.length === 0) {
    return null;
  }

  return (
    <section className="container mx-auto px-4 py-16">
      <h2 className="text-3xl font-bold text-center mb-4">Featured Events</h2>
      <p className="text-gray-600 text-center max-w-2xl mx-auto mb-12">
        Don't miss these popular Sydney events handpicked just for you
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {events.map((event) => (
          <EventCard key={event.id} event={event} onTicketClick={onTicketClick} />
        ))}
      </div>
    </section>
  );
};