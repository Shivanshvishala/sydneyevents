import React from 'react';
import { Calendar, MapPin, Clock } from 'lucide-react';
import { Event } from '../types';
import { formatDate, formatEventTime, getCategoryColor, truncateText } from '../utils/formatters';
import { Link } from './Link';

interface EventCardProps {
  event: Event;
  onTicketClick: (eventId: string) => void;
}

export const EventCard: React.FC<EventCardProps> = ({ event, onTicketClick }) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 hover:shadow-lg hover:-translate-y-1">
      <div className="relative h-48 overflow-hidden">
        <img 
          src={event.image} 
          alt={event.title} 
          className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
        />
        <div className={`absolute top-0 right-0 px-3 py-1 m-2 text-xs font-bold text-white ${getCategoryColor(event.category)} rounded-full`}>
          {event.category.charAt(0).toUpperCase() + event.category.slice(1)}
        </div>
      </div>
      
      <div className="p-5">
        <h3 className="text-xl font-bold text-gray-800 mb-2">{event.title}</h3>
        
        <p className="text-gray-600 mb-4">{truncateText(event.description, 120)}</p>
        
        <div className="flex items-center text-gray-500 mb-2">
          <Calendar size={16} className="mr-2" />
          <span>{formatDate(event.date)}</span>
        </div>
        
        <div className="flex items-center text-gray-500 mb-2">
          <Clock size={16} className="mr-2" />
          <span>{formatEventTime(event.time)}</span>
        </div>
        
        <div className="flex items-center text-gray-500 mb-4">
          <MapPin size={16} className="mr-2" />
          <span>{event.venue}, {event.location}</span>
        </div>
        
        <div className="flex justify-between items-center mt-4">
          <span className="font-bold text-indigo-600">{event.price}</span>
          <button
            onClick={() => onTicketClick(event.id)}
            className="bg-pink-600 hover:bg-pink-700 text-white px-4 py-2 rounded font-medium transition-colors"
          >
            GET TICKETS
          </button>
        </div>
      </div>
    </div>
  );
};